package it.uniroma3.model;

import java.util.List;

public class Fornitore {
	
	private int idFornitore;
	private int pIva;
	private String indirizzo;
	private String telefono;
	private String email;
	private List<Prodotto> prodotti;

public Fornitore() {
}

public int getpIva() {
	return pIva;
}

public void setpIva(int pIva) {
	this.pIva = pIva;
}

public String getIndirizzo() {
	return indirizzo;
}

public void setIndirizzo(String indirizzo) {
	this.indirizzo = indirizzo;
}

public String getTelefono() {
	return telefono;
}

public void setTelefono(String telefono) {
	this.telefono = telefono;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public int getIdFornitore() {
	return idFornitore;
}

public void setIdFornitore(int idFornitore) {
	this.idFornitore = idFornitore;
}

public List<Prodotto> getProdotti() {
	return prodotti;
}

public void setProdotti(List<Prodotto> prodotti) {
	this.prodotti = prodotti;
}


}

