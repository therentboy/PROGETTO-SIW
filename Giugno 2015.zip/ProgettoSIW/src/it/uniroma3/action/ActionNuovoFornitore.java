package it.uniroma3.action;

import it.uniroma3.helper.HelperNuovoFornitore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ActionNuovoFornitore extends Action {

	public ActionNuovoFornitore() {

	}

	public String esegui(HttpServletRequest request) {

		HttpSession session = request.getSession();
		HelperNuovoFornitore helper = new HelperNuovoFornitore(request);

		String campiValidi = "campiValidiFornitore";
		String piva = request.getParameter("piva");
		String indirizzo = request.getParameter("indirizzo");
		String telefono = request.getParameter("telefono");
		String email = request.getParameter("email");

		request.setAttribute("piva", piva);
		request.setAttribute("indirizzo", indirizzo);
		request.setAttribute("telefono", telefono);
		request.setAttribute("email", email);

		if (helper.convalida()) {
			session.setAttribute("piva", piva);
			session.setAttribute("indirizzo", indirizzo);
			session.setAttribute("telefono", telefono);
			session.setAttribute("email", email);
		} else {
			campiValidi = "campiNONvalidiFornitore";
			request.setAttribute("errore", "valori errati");
		}

		return campiValidi;
	}
}
