package it.uniroma3.action;

import java.util.List;

import it.uniroma3.model.Fornitore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ActionVisualizzaFornitori extends Action {

	public ActionVisualizzaFornitori() {

	}

	public String esegui(HttpServletRequest request) {

		HttpSession session = request.getSession();

		String esito = "ErroreFornitori";
		List<Fornitore> fornitori;
		fornitori = facade.getFornitori();
		if (fornitori != null) {
			session.setAttribute("fornitori", fornitori);
			esito = "fornitoriOK";

		}
		return esito;
	}
}
