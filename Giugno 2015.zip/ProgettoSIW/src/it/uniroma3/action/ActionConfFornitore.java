package it.uniroma3.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ActionConfFornitore extends Action{

	public ActionConfFornitore(){

	}

	public String esegui(HttpServletRequest request) {

		HttpSession session = request.getSession();

		String risposta = request.getParameter("si/no");
		String esito;

		if (risposta.equals("NO")) {
			request.setAttribute("riprova", "Ripeti la registrazione");
			esito = "fornitoreNONconf";
		} else {

	
			String piva = (String) session.getAttribute("piva");
			String indirizzo = (String) session.getAttribute("indirizzo");
			String telefono = (String) session.getAttribute("telefono");
			String email = (String) session.getAttribute("email");

			if (facade.registraFornitore(piva, indirizzo, telefono, email))
				esito = "fornitoreRegistrato";
			else{
				esito = "erroreRegistrazione";
				request.setAttribute("erroreChiave", "PARTITA IVA gia utilizzata");
			}

		}
		return esito;
	}
}
