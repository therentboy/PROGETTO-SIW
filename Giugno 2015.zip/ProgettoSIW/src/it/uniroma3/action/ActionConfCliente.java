package it.uniroma3.action;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ActionConfCliente extends Action{

	public ActionConfCliente(){

	}

	public String esegui(HttpServletRequest request) {

		HttpSession session = request.getSession();

		String risposta = request.getParameter("si/no");
		String esito;

		if (risposta.equals("NO")) {
			request.setAttribute("riprova", "Ripeti la registrazione");
			esito = "clienteNONconf";
		} else {

			Date today = Calendar.getInstance().getTime(); 
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String dataR = dateFormat.format(today);
	
			String nome = (String) session.getAttribute("nome");
			String cognome = (String) session.getAttribute("cognome");
			String email = (String) session.getAttribute("email");
			String indirizzo = (String) session.getAttribute("indirizzo");
			String dataN = (String) session.getAttribute("dataN");
			String username = (String) session.getAttribute("username");
			String password = (String) session.getAttribute("password");

			if (facade.registraCliente(nome, cognome, indirizzo, email, dataN, dataR , username,
					password))
				esito = "clienteRegistrato";
			else{
				esito = "erroreRegistrazione";
				request.setAttribute("erroreChiave", "USERNAME gia utilizzata");
			}

		}
		return esito;
	}
}
