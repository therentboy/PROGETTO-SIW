package it.uniroma3.helper;

import javax.servlet.http.HttpServletRequest;

public class HelperNuovoFornitore {
	protected HttpServletRequest request;

	public HelperNuovoFornitore(HttpServletRequest request) {
		this.request = request;

	}

	public boolean convalida() {
		
		String piva = request.getParameter("piva");
		String indirizzo = request.getParameter("indirizzo");
		String telefono = request.getParameter("telefono");
		String email = request.getParameter("email");

		boolean campiValidi = true;

		if (piva == null || piva.isEmpty()) {
			campiValidi = false;
			request.setAttribute("errorePiva", "inserisci una partita IVA");
		}

		if (indirizzo == null || indirizzo.isEmpty()) {
			campiValidi = false;
			request.setAttribute("Indirizzo", "inserisci un indirizzo");
		}

		if (telefono == null || telefono.isEmpty()) {
			campiValidi = false;
			request.setAttribute("erroreTelefono",
					"inserisci un numero di Telefono");
		}
		
		if (email == null || email.isEmpty()) {
			campiValidi = false;
			request.setAttribute("erroreEmail",
					"inserisci una Email");
		}

				
		return campiValidi;

	}
	
}
	