package it.uniroma3.exceptions;

public class PersistenceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PersistenceException(String message) {
		// TODO Auto-generated constructor stub
	}

}
