package it.uniroma3.persistence;

import java.util.List;

import it.uniroma3.exceptions.PersistenceException;
import it.uniroma3.model.Ordine;
import it.uniroma3.model.RigaOrdine;
import it.uniroma3.model.Prodotto;

public interface RigaOrdineDAO {

	public boolean insert(RigaOrdine riga, Ordine ordine)
			throws PersistenceException;
	
	// Ritorna la lista dei prodotti presenti in un ordine //
	public List<Prodotto> findProdottiInOrdine(Ordine ordine) 
			throws PersistenceException;
}
