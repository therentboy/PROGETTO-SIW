package it.uniroma3.persistence;

import java.util.List;

import it.uniroma3.exceptions.PersistenceException;
import it.uniroma3.model.Fornitore;

public interface FornitoreDAO {

	public boolean insert(String piva, String indirizzo, String telefono, String email) throws PersistenceException;

	public List<Fornitore> findAll() throws PersistenceException;
}

