package it.uniroma3.persistence.postgres;

import it.uniroma3.exceptions.PersistenceException;
import it.uniroma3.model.Fornitore;
import it.uniroma3.persistence.DataSource;
import it.uniroma3.persistence.FornitoreDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class fornitoreDAOpostgres implements FornitoreDAO {
	
	private DataSource ds;
	private PreparedStatement statement;
	private Connection connection;

	public fornitoreDAOpostgres() {
		super();
		this.ds = new DataSource();

	}

	@Override
	public boolean insert(String piva, String indirizzo, String telefono, String email) throws PersistenceException {

		Boolean b = false;
		this.connection = ds.getConnection();
		String insert = "INSERT INTO fornitore(piva, indirizzo, telefono, email, idfornitore) VALUES(?,?,?,?,?)";

		try {

			this.statement = this.connection.prepareStatement(insert);

			Long idFornitore = IdBroker
					.getId(connection, "sequenza_id_fornitore");
			this.statement.setLong(5, idFornitore);

			this.statement.setString(1, piva);
			this.statement.setString(2, indirizzo);
			this.statement.setString(3, telefono);
			this.statement.setString(4, email);

			b = (this.statement.executeUpdate() != 0);

		} catch (SQLException e) {
			e.printStackTrace();
			throw new PersistenceException(e.getMessage());

		} finally {
			try {
				if (this.statement != null)
					this.statement.close();
				if (this.connection != null)
					this.connection.close();
			} catch (SQLException e) {
				throw new PersistenceException(e.getMessage());
			}
		}
		return b;

	}
	
	@Override
	public List<Fornitore> findAll() throws PersistenceException {

		this.connection = ds.getConnection();
		Fornitore f;
		List<Fornitore> fornitori = null;

		String find = "SELECT * FROM fornitore";
		try {

			this.statement = this.connection.prepareStatement(find);
			ResultSet result = this.statement.executeQuery();

			fornitori = new ArrayList<Fornitore>();

			while (result.next()) {
				f = new Fornitore();
				f.setIdFornitore(result.getInt("idFornitore"));
				f.setpIva(result.getInt("piva"));
				f.setIndirizzo(result.getString("indirizzo"));
				f.setTelefono(result.getString("telefono"));
				f.setEmail(result.getString("email"));

				fornitori.add(f);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PersistenceException(e.getMessage());

		} finally {
			try {
				if (this.statement != null)
					this.statement.close();
				if (this.connection != null)
					this.connection.close();
			} catch (SQLException e) {
				throw new PersistenceException(e.getMessage());
			}

		}
		return fornitori; // null se problemi
	}

}
